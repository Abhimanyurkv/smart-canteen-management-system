# Smart Canteen Management System

An RFID-based canteen ordering and billing system built on an ATmega328 (Arduino) and an ESP-01 (ESP8266) Wi-Fi module. Users tap an RFID card, browse the menu on an LCD with a 4x4 keypad, and the bill is deducted from their card balance automatically. Canteen staff manage users, menu, stock, orders and sales reports from a web admin panel hosted by the ESP-01.

**S6 Mini Project** | B.Tech Electronics and Communication Engineering
Government Engineering College, Wayanad (APJ Abdul Kalam Technological University) | March 2026
**Group 03** | Guide: Prof. Aravind

![Final product](images/final-product.jpg)

## Demo

Demo video: _add link here_

## Problem

- Long queues and waiting time in traditional canteens
- Manual billing and cash handling cause errors and slow service
- Staff struggle to manage many orders at once

## Features

**At the counter (Arduino)**
- Contactless login with RFID cards (MFRC522)
- Menu browsing, quantity entry and cart handling on a 16x2 I2C LCD with a 4x4 keypad
- Cart tools: view, edit quantity, delete item, clear, cancel
- Automatic bill calculation using the card **balance plus an optional credit limit**
- Stock-aware ordering (out-of-stock items cannot be added)
- Order token shown after a successful order, and a "READY" alert with beeps when the kitchen finishes
- Buzzer and LED feedback (access granted/denied, success, error), sound on/off toggle
- Session timeout after 60 seconds of inactivity

**Web admin panel (ESP-01)**
- Admin login
- Dashboard with live clock (NTP, IST), user, menu, pending and online counts
- User management: add (scan a card from the browser), edit, delete, recharge balance
- Menu and inventory management with stock levels and low-stock alerts
- Kitchen panel: live order queue with Ready / Cancel buttons
- Reports: total sales, daily sales chart, top items, transaction history, top spenders
- Lock / unlock the whole system with a custom message
- Export users, menu and orders as CSV/TXT, and download reports
- Data saved in EEPROM, so it survives power cuts

## Hardware

| Component | Purpose |
|---|---|
| ATmega328P (Arduino UNO/Nano) | Main controller: card reading, menu, cart, billing |
| ESP-01 (ESP8266) | Wi-Fi, web server, data storage, REST API |
| MFRC522 RFID reader + cards | User identification |
| 16x2 LCD with I2C (address 0x27) | User interface |
| 4x4 membrane keypad | Menu navigation and ordering |
| Buzzer + 2 LEDs | Audio / visual feedback |
| 5V power supply | Power |

### Pin map (Arduino)

| Signal | Pin |
|---|---|
| RFID SS / RST | D9 / D10 (SPI on D11, D12, D13) |
| Keypad rows | D2, D3, D4, D5 |
| Keypad columns | D6, D7, D8, A0 |
| Buzzer | A1 |
| LED granted / denied | A2 / A3 |
| LCD (I2C) | A4 (SDA), A5 (SCL) |
| ESP-01 | Serial TX/RX at 9600 baud |

## Block Diagram

![Block diagram](images/block-diagram.png)

## Circuit Diagram

![Circuit diagram](images/circuit-diagram.png)

## How It Works

1. LCD shows **Scan Card...**
2. User taps a card. Arduino sends `UID:<id>` to the ESP-01 over serial.
3. ESP-01 replies `VALID,name,balance,creditUsed,creditLimit`, `INVALID` or `LOCKED,message`.
4. On success the Arduino requests the menu (`MENU`) and shows items one by one.
5. User picks items and quantities, then places the order with `*`.
6. Arduino sends the order (`ORDER_START ... ORDER_END`). ESP-01 stores it, updates balance and stock, and replies `ORDER_OK,token`.
7. The order appears in the **Kitchen** tab. When staff press **Ready**, the counter beeps and shows `READY`.
8. Session ends and the LCD returns to **Scan Card...**

### Keypad controls

| Key | Function |
|---|---|
| A / B | Next / previous menu item |
| C | Select item (enter quantity) / confirm |
| D | Exit session / back |
| * | Place order (backspace while typing a quantity) |
| # | View cart |
| 1 | Cart total |
| 2 | Balance and credit |
| 3 | Clear cart |
| 4 | Cancel order and exit |
| 5 | Edit cart |
| 6 | Sound on/off |
| 7 | Delete cart item |
| 0 | Help |

## Repository Structure

```
.
├── firmware/smart_canteen_arduino/   Arduino (ATmega328P) sketch
├── esp01/smart_canteen_esp01/        ESP-01 sketch (web server + API + admin page)
├── images/                           Photos and diagrams
├── docs/                             Project report and presentation
└── README.md
```

## Getting Started

**Libraries** (Arduino Library Manager): `MFRC522`, `LiquidCrystal_I2C`, `Keypad`, `ArduinoJson`. The ESP8266 core is needed for the ESP-01 (add the ESP8266 board package in the Arduino IDE).

1. Wire the circuit as in the circuit diagram.
2. Upload `firmware/smart_canteen_arduino` to the Arduino.
3. Open `esp01/smart_canteen_esp01`, set your Wi-Fi name, password, static IP and gateway, **and change the admin password**, then upload it to the ESP-01.
4. Power everything. The ESP-01 prints its IP over serial once connected.
5. Open `http://<ESP-IP>/` in a browser on the same network and log in.
6. Add menu items and users (scan a card from the browser), recharge balances, then try a card at the counter.

> **Security note:** the Wi-Fi credentials and admin password in this repo are placeholders. Set your own locally and never commit them. This is a prototype: the admin panel is plain HTTP on a local network.

## Future Scope

- Mobile app for ordering
- Online payments (UPI, QR code)
- Cloud database for large-scale deployment
- AI-based food recommendations
- Multi-canteen or campus-wide rollout

## Team (Group 03)

| Name | Role |
|---|---|
| Abhimanyu Ratheesan K V | _add role_ |
| Arun P | _add role_ |
| Akash Krishna C S | _add role_ |
| Sujay M K | _add role_ |

**Guide:** Prof. Aravind, Assistant Professor, ECE Department, GEC Wayanad

## Acknowledgements

Thanks to our guide Prof. Aravind, project coordinators Prof. Reeha K R and Prof. Helen J, the Head of Department Dr. Sinith M. S., and the Principal Dr. Pradeev V, for their support. (Please check the spelling of names against your report.)

## References

1. H. Menewar, S. Bhandari, P. Mahajan, K. Dange, "Smart Canteen and Cafeteria Management System using RFID Technology," IJRASET, 2023. https://www.ijraset.com/research-paper/smart-canteen-and-cafeteria-management-system
2. RFID Based Prepaid Card for School Canteen. https://journalijiar.com/article/665/rfid-based-prepaid-and-value-card-for-school-canteen/
3. Arduino Forum: RC522 RFID with ESP8266 Web Interface. https://forum.arduino.cc/t/mfrc522-rc522-rfid-on-esp8266-featuring-websocket-json-javascript
